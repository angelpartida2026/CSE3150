# Final Project

## How to Build

Download the Final folder zip and open a codespace

codespace> cd Final
codespace> g++ main.cpp -std=c++17 -o final

## How to Run

codespace> ./final