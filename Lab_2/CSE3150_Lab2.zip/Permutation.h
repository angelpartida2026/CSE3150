#ifndef _PERMUTATION_H
#define _PERMUTATION_H

struct Permutation {
    inline static int value = 0;

    void setValue(int myValue) {
        value = myValue;
    }
};

#endif
