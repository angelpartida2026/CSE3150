# Lab Week 2

## How to Build

Download the Lab_2 folder and open a codespace

codespace> cd Lab_2
codespace> g++ -std=c++11 -I../include -o simulation mainSimulation.cpp BalancedLists.cpp

## How to Run

codespace> ./simulation

