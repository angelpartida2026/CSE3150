# Lab 4

## How to Build

Download the Lab_5 folder zip and open a codespace

codespace> cd Lab_5
codespace> g++ -std=c++17 main.cpp vector_utils.cpp cosine_distance.cpp -o lab5

## How to Run

codespace> ./lab5