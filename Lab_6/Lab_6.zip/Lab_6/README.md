# Lab 6

## How to Build

Download the Lab_6 folder zip and open a codespace

codespace> cd Lab_6
codespace> g++ -std=c++17 main.cpp Tokenizer.cpp -o lab6

## How to Run

codespace> ./lab6