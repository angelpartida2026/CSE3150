# Lab 9

## How to Build

Download the Lab_9 folder zip and open a codespace

codespace> cd Lab_9
codespace> g++ main.cpp LinkedList.cpp -std=c++17 -o lab9

## How to Run

codespace> ./lab9