# Lab 8

## How to Build

Download the Lab_8 folder zip and open a codespace

codespace> cd Lab_8
codespace> g++ main.cpp nftoken.cpp ManageTokens.cpp -lcrypto -std=c++17 -o lab8

## How to Run

codespace> ./lab8