# Lab Week 1: Prefix Sums

## Overview
- `non_negative_prefix_sum`: Checks that the prefix sums of an array (containing only +1 and -1) never go below zero.
- `non_pos_prefix_sum`: Checks that the prefix sums never go above zero.

## How to Build and Run

codespace> g++ -std=c++11 -o a.out main.cpp
codespace> ./a.out
