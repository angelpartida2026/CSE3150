# Lab Week 4

## How to Build

Download the Lab_4 folder zip and open a codespace

codespace> cd Lab_4
codespace> g++ -std=c++17 main.cpp LinkedList.cpp -o lab4

## How to Run

codespace> ./lab4