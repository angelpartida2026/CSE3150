# Lab Week 3

## How to Build

Download the Lab_3 folder zip and open a codespace

codespace> cd Lab_3
codespace> g++ -std=c++11 -I../include -o test main.cpp LinkedList.cpp

## How to Run

codespace> ./test