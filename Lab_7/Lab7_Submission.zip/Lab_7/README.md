# Lab 7

## How to Build

Download the Lab_7 folder zip and open a codespace

codespace> cd Lab_7
codespace> g++ main.cpp -o lab7 -std=c++17

## How to Run

codespace> ./lab7